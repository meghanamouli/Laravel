<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>BookFinder Challenge</title>
    <link rel="stylesheet" type="text/css" href="/bookfinder/public/css/app.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.2/css/font-awesome.min.css">
</head>

<body>
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <bold><a class="navbar-brand" href="/bookfinder/public/order" style="font-size:20px; background-color:#ffa500; color:#fff">BookFinder Challenge</a></bold>
        </div>

        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li style="font-size:16px;"><a href="/bookfinder/public/recent">Recent Addition</a></li>
            <li style="font-size:16px;"><a href="/bookfinder/public/contact">Contact</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="\">Register</a></li>
            <li class="active"><a href="./bookFinder">Login</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container layout">
        <div class="col-md-12">
            @yield('content')
        </div>
    </div>

</body>
</html>