@extends('layout')

@section('content')

    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-3" style="text-align: center;padding: 1%;">
            <h3>Contact Details</h3><hr>

            <strong>Phone</strong>
            <p>07777777777</p>

            <strong>Fax</strong>
            <p>055555555</p>

            <strong>Email</strong>
            <p>example@bookfinder.com</p>
        </div>
        <div class="col-md-6 form">
            <h4>Thank you for your Message {{ $username }}. <br> Will come back to you soon</h4>
        </div>
    </div>

@stop