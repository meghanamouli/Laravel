@extends('layout')

@section('content')

    <div class="col-md-12" id="searchwrap">
        <div style="float: right; margin-top: 1%;">
          <form id="search-form" name="search" action="/bookfinder/public/order" method="get">
            Search: <input id="search-input" name="search" type="text" style="border-radius:2%">
          </form>
        </div>
        
    </div>

    <div class="row">
    @foreach($titles as $name)
      <div class="col-md-2 column">
         #: {{ $name->id }}; &nbsp ISBN: <strong>{{ $name->code }} </strong>
        <br>Author Name: <strong>{{ $name->name }} </strong>
        <br>Book Title: <strong>{{ $name->title }}</strong>
        <br>
        <br><button class="btn btn-info"><span>
                More&nbsp <i id="info" class="fa fa-info-circle" aria-hidden="true" 
                  style="font-size: 18px;padding: 2px;" 
                  onClick="moreInfo()" return false;></i>
              </span></button>
      </div>
    @endforeach
    </div>
@stop

<script type="text/javascript">
  function moreInfo() {
    location.href = 'http://amazon.co.uk';
  }
</script>