@extends('layout')

@section('content')


    <div class="jumbotron">
        <form action="./bookFinder" method="post" class="form-horizontal">
        {{ csrf_field() }}
            <h3>Please sign in </h3>
            <h4>Use a local account to log in</h4>
            <hr>
            <div class="form-group">
                <label class="col-sm-2 control-label">Email</label>
                <div class="col-sm-6">
                    <input class="form-control" id="email" name="email" type="text" placeholder="Email">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">Password</label>
                <div class="col-sm-6">
                    <input class="form-control" id="password" name="password" type="password" placeholder="Password">
                </div>
            </div>
            <div class="form-group">
                <div class="col-md-3"></div>
                <div class="col-sm-3">
                    <input type="submit" value="Sign In" class="form-control btn btn-lg btn-success">
                </div>
            </div>
        </form>    
    </div>
@stop