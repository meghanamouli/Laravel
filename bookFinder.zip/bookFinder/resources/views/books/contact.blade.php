@extends('layout')

@section('content')

    <div class="row">
    	<div class="col-md-1"></div>
    	<div class="col-md-3" style="text-align: center;padding: 5%;">
            <h3>Contact Details</h3><hr>

        	<strong>Phone</strong>
    		<p>07777777777</p>

    		<strong>Fax</strong>
    		<p>055555555</p>

    		<strong>Email</strong>
    		<p>example@bookfinder.com</p>
    	</div>
    	<div class="col-md-6 form">
    		<H4 style="padding:2%"><strong>Enquire / Contact Form</strong></H4>
    		<form id="search-form" name="search" action="/bookfinder/public/contact" method="post" enctype="multipart/form-data" role="form">
                {{ csrf_field() }}
    			<div class="form-group">
    				<label>Name * : </label> <input type="text" class="form-control" name="username">
    				<label>Email Address * :</label> <input type="text" class="form-control" name="useremail">
    				<label>Phone Number :</label><input type="text" class="form-control" name="usernumber">
    				<label>Message * :</label><textarea row="5" class="form-control" name="usermessage"></textarea>
    			</div>
    			<input type="submit" value="Submit" class="btn btn-lg btn-success">
    		</form>
    	</div>

    </div>

@stop