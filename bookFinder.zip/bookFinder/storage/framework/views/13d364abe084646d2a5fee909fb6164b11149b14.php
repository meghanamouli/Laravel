<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Matt's Pizzeria</title>
    <link rel="stylesheet" type="text/css" href="/blogg/public/css/app.css">

    
</head>

<body>
    <div class="container layout">
        <div class="masthead">
        <h3 class="text-muted">Matt's Pizza</h3>
        <nav>
          <ul class="nav nav-justified">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#">Projects</a></li>
            <li><a href="#">Services</a></li>
            <li><a href="#">Downloads</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </nav>
      </div>

    <div class="col-md-12">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
</html>