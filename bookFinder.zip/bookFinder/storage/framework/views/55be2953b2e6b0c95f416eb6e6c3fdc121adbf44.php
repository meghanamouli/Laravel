<?php $__env->startSection('content'); ?>

    <div class="table-responsive col-md-12" style="margin-top:2%">
      <table class="table table-striped dataTables">
        <thead>
          <tr style="background-color:#e6e6e6;">
            <th>Author</th>
            <th>Book Title</th>
            <th>ISBN Number</th>
            <th>Added On</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($titles as $name): ?>
          <tr>
            <td><?php echo e($name->name); ?></td>
            <td><?php echo e($name->title); ?></td>
            <td><?php echo e($name->code); ?></td>
            <td><?php echo e($name->created_at); ?></td>
            <td>
              <span>
                <i id="info" class="fa fa-info-circle btn-info" aria-hidden="true" 
                  style="border-radius: 15px;font-size: 28px;padding: 8px;" 
                  onClick="moreInfo()" return false;></i>
              </span>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <div>
<?php $__env->stopSection(); ?>

<script type="text/javascript">
  function moreInfo() {
    location.href = 'http://amazon.co.uk';
  }
</script>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>