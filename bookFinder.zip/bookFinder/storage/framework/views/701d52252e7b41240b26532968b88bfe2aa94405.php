<?php $__env->startSection('content'); ?>

<div class="col-md-8">
	<div class="col-md-4"></div>
	<div class="col-md-4" style="color:black; border:1px solid red">Select Base</div>
	<div class="col-md-4" style="color:black; border:1px solid red">Select Toppings</div>
	<div class="col-md-4"></div>
</div>

<div class="col-md-4">

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>