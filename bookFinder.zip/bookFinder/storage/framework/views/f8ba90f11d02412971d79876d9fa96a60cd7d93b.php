<?php $__env->startSection('content'); ?>

    <div class="col-md-12" id="searchwrap">
        <div style="float: right; margin: 2%;">
          <form id="search-form" name="search" action="/bookfinder/public/order" method="get">
            Search: <input id="search-input" name="search" type="text" style="border-radius:2%">
          </form>
        </div>
        
    </div>

    <div class="row">
    <?php foreach($titles as $name): ?>
      <div class="col-md-3" style="    text-align: left;
    background-color: #e6e6e6;
    padding: 3%;
    margin: 2%;
    border: 2px #286090;
    border-style: solid;">
         #: <?php echo e($name->id); ?>; &nbsp ISBN: <strong><?php echo e($name->code); ?> </strong>
        <br>Author Name: <strong><?php echo e($name->name); ?> </strong>
        <br>Book Title: <strong><?php echo e($name->title); ?></strong>
        <br>
        <br><button class="btn btn-info"><span>
                More&nbsp <i id="info" class="fa fa-info-circle" aria-hidden="true" 
                  style="font-size: 18px;padding: 2px;" 
                  onClick="moreInfo()" return false;></i>
              </span></button>
      </div>
    <?php endforeach; ?>
    </div>
<?php $__env->stopSection(); ?>

<script type="text/javascript">
  function moreInfo() {
    location.href = 'http://amazon.co.uk';
  }
</script>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>