<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-3" style="text-align: center;padding: 1%;">
            <h3>Contact Details</h3><hr>

            <strong>Phone</strong>
            <p>07777777777</p>

            <strong>Fax</strong>
            <p>055555555</p>

            <strong>Email</strong>
            <p>example@bookfinder.com</p>
        </div>
        <div class="col-md-6" style="border-radius: 5px;background-color: #dcdcdc;padding: 20px;margin-top: 2%;">
            <h4>Thank you for your Message <?php echo e($username); ?>. <br> Will come back to you soon</h4>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>