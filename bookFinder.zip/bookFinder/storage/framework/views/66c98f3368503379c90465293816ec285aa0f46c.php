<?php $__env->startSection('content'); ?>

    <div class="col-md-12" id="searchwrap">
        <div style="float: right; margin-top: 1%;">
          <form id="search-form" name="search" action="/bookfinder/public/order/search" method="get">
            Search: <input id="search-input" name="search" type="text" style="border-radius:2%">
          </form>
        </div>
        
    </div>

    <div class="row">
    <?php foreach($titles as $name): ?>
      <div class="col-md-2 column">
         #: <?php echo e($name->id); ?>; &nbsp <strong><?php echo e($name->title); ?></strong><br>ISBN: <strong><?php echo e($name->code); ?> </strong><br>
        Author Name: <strong><?php echo e($name->name); ?> </strong><br>
        <br><button class="btn btn-info" style="position: absolute;right: 5px;bottom: 5px;"><span>
                More&nbsp <i id="info" class="fa fa-info-circle" aria-hidden="true" 
                  style="font-size: 18px;padding: 2px;" 
                  onClick="moreInfo()" return false;></i>
              </span></button>
      </div>
    <?php endforeach; ?>
    </div>
<?php $__env->stopSection(); ?>

<script type="text/javascript">
  function moreInfo() {
    location.href = 'http://amazon.co.uk';
  }
</script>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>