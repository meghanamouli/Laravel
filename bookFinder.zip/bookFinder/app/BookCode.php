<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookCode extends Model
{
	protected $table = 'bookcode';
	
    protected $fillable = ['author_id', 'code', 'title'];

    public function books()
	{
		$this->belongsTo('App\Author');
	}
}
