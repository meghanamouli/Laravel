<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use Illuminate\Support\Facades\Input;
use Redirect;

use App\Author;
use App\BookCode;

use App\Http\Requests;

class BookController extends Controller
{
    public function index()
    {
    	return view('books.index');
    }

    public function signin(Request $request)
    {
        $email = $request->email;
        $password = $request->password;
        $titles = DB::select(DB::raw("SELECT bookcode.id, author.name, bookcode.title, bookcode.code, bookcode.created_at FROM `bookcode` JOIN author ON author.id = bookcode.author_id"));


        if ($true = DB::select(DB::raw("SELECT * FROM `user` WHERE `email`= '$email' AND `password`= '$password' "))) {
            return view('books.order', compact('titles'));
        } else {
            return view('books.index');
        }
    }

    public function manageOrder()
    {
        $titles = DB::select(DB::raw("SELECT bookcode.id, author.name, bookcode.title, bookcode.code, bookcode.created_at FROM `bookcode` JOIN author ON author.id = bookcode.author_id"));
    	return view('books.order', compact('titles'));

    }

    public function searchResult($search, Request $request)
    {
        $titles = DB::select(DB::raw("SELECT author.name, bookcode.title, bookcode.code, bookcode.created_at FROM `bookcode` JOIN author ON author.id = bookcode.author_id WHERE bookcode.title LIKE '%$request->search%'"));
    	return view('books.search', compact('titles'));
    }

    public function recentAddition()
    {
        $titles = DB::select(DB::raw("SELECT bookcode.id, author.name, bookcode.title, bookcode.code, bookcode.created_at FROM `bookcode` JOIN author ON author.id = bookcode.author_id order BY bookcode.created_at DESC"));
        return view('books.recent', compact('titles'));
    }

    public function contact()
    {
        return view('books.contact');
    }

    public function email(Request $request)
    {
        $username = $request->username;
        $useremail = $request->useremail;
        $usernumber = $request->usernumber;
        $usermessage = $request->usermessage;

        $to = "meghanasmouli@gmail.com";
        $subject = "Enquiry Message";
        $message = $usernumber . $usermessage;
        $header = $useremail;
        mail($to, $subject, $message,$header);
        return view('books.contact1', compact('username'));
    }
}