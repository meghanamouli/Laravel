<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Author extends Model
{
	protected $table = 'author';
	
    protected $fillable = ['name', 'description'];

    public function bookAuthor()
	{
		return $this->hasMany('App\BookCode');
	}

	public function userSearch()
	{
		return $this->hasMany('App\Userbook');
	}
}
