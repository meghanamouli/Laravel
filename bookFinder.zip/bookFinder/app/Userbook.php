<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookCode extends Model
{
	protected $table = 'bookcode';
	
    protected $fillable = ['user_id', 'bookcode_id'];

    public function code()
	{
		$this->belongsTo('App\BookCode');
	}

	public function users()
	{
		$this->belongsTo('App\User');
	}
}
